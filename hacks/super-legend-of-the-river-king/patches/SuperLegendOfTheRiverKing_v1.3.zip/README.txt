================================================================
  SUPER LEGEND OF THE RIVER KING
  English translation of Kawa no Nushi Tsuri 2 (SFC, 1995)
  Version 1.3
================================================================

ABOUT
-----
Kawa no Nushi Tsuri 2 is a fishing RPG for the Super Famicom. Choose
one of four family members and travel down a river, from mountain
streams to the sea, to catch the legendary River King. Along the way
you fill in your Fishing Notes, trade with villagers, and help the
people you meet.

This patch translates the whole game into English. It is named
in the style of the Game Boy entries in the series, which were
released in the West as "Legend of the River King".


WHAT IS TRANSLATED
------------------
 * All dialogue, story scenes, letters, postcards and endings
 * All menus, shop and item names, and fishing gear
 * The Fishing Notes: contents page, area maps and every fish entry
 * Name entry: a new English keyboard for character names (up to
   8 letters), with default names Taro, Kyoko, Yuzo and Noriko
 * Postcards: a full English keyboard with upper case, lower case and
   symbol pages, and 28 letters per line
 * The title screen logo
 * Graphics: menu labels, status windows, town signs, shop banners,
   map labels and item icons

Fish use their English common names, with Japanese names only where no
English name exists (Higai, Wataka, Itomoroko and a few others).
Money is shown in yen.


APPLYING THE PATCH
------------------
The patch is an IPS file: KawaNoNushiTsuri2_EN_v1.3.ips

Apply it with any IPS patcher, for example Lunar IPS, Floating IPS
(Flips), or the online patcher at romhacking.net. Patch a copy of
your ROM, not the original.

This patch needs the following ROM, with no copier header:

  Name:   Kawa no Nushi Tsuri 2 (Japan).sfc
  Size:   1,572,864 bytes (12 Mbit)
  CRC32:  716D3EFF
  MD5:    120f97e5855bfe8e31961fbf387e4150
  SHA-1:  c2103dd94e2a1a65a495fc02adc2e7d040f31212

If your file is 1,573,376 bytes, it has a 512-byte copier header.
Remove it first (Flips and most ROM tools can do this).

After patching, the ROM grows to 2 MB (16 Mbit):

  Size:   2,097,152 bytes
  CRC32:  8F2E0D10
  MD5:    e3b152d65f862fcde556ae04ba5e2d47
  SHA-1:  e8c94a106e9aafb5d85cb67b2b6266a474f31c47

The patched game was tested in Mesen-S.


CHANGES IN 1.3
--------------
 * The empty gear slots in the tackle window (switch fishing styles
   with Select) now read ROD, FLOAT, SINKER, HOOK and NONE instead
   of Japanese.


CHANGES IN 1.2
--------------
 * The hidden name that unlocks a fully stocked tackle box now works
   with the English keyboard (see SECRETS below).
 * Reworded one villager's line.


CHANGES IN 1.1
--------------
 * Script revision: speaker names in the opening scenes and at shops
   and inns, a fuller opening with Sanpei, reworded contest and save
   messages, and signatures on the ending letters and certificates.
 * Fixed the end-of-game letters and certificates overflowing their
   postcard frame (they now fit in 5 lines).


NOTES
-----
 * Saves from the Japanese game, or from earlier test versions of this
   patch, may show Japanese names as garbled letters. Start a new game,
   or rename your characters, to fix this.
 * The Stereo/Mono option is an item in the Fishing Note's Items menu,
   just as in the original game.
 * The Fishing Note map uses short forms for some long fish names
   (for example "Masu Tr." and "W.Crucian"), and so does the fishery
   price window. Everywhere else the full names are used.


SECRETS
-------
The original game has a hidden name for the first character (the
older brother): naming him "Tsuri Taro" - the developers' earlier
fishing game - gives him a fully stocked tackle box. In this
translation, name him:

    FishTaro

(exactly as written: capital F and T, no space).


CREDITS
-------
 Testing, direction, and the title logo art ... [your name here]
 Translation and ROM hacking .................. produced with Claude
                                                (Anthropic)

 Original game: Kawa no Nushi Tsuri 2
 (c) 1995 Pack-In-Video / Yuu Yuu

This is an unofficial fan translation. It is not affiliated with or
endorsed by the original developers or publishers. Please do not
distribute patched ROMs; distribute only the patch file.
